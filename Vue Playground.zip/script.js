import { createApp } from 'vue'
import App from './App.vue'

console.log('Hello world')

createApp(App).mount('#app')